﻿namespace OrbitBubble.Domain.Gestures;

public enum GestureResult {
  None = 0,
  Circle = 1
}
