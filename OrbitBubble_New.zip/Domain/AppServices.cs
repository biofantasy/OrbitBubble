﻿namespace OrbitBubble.Domain;

public static class AppServices {
  public static IServiceProvider Provider { get; internal set; } = default!;
}
